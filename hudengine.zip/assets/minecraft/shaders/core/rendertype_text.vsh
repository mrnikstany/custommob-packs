#version 150

#moj_import <minecraft:fog.glsl>

#define HEIGHT_BIT 13
#define MAX_BIT 10
#define ADD_OFFSET 4095
#define DEFAULT_OFFSET 10

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler2;
uniform mat4 ModelViewMat;
uniform mat4 ProjMat;
uniform int FogShape;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

bool isVanillaLevelText(vec3 pos, vec2 ui, vec4 color) {
    if (ProjMat[3].x != -1.0) {
        return false;
    }
    bool inBand = pos.y >= ui.y - 60.0 && pos.y <= ui.y - 20.0
            && pos.x >= ui.x * 0.5 - 60.0 && pos.x <= ui.x * 0.5 + 60.0;
    if (!inBand) {
        return false;
    }
    vec3 levelColor = vec3(128.0, 255.0, 32.0);
    return (all(greaterThanEqual(color.rgb, levelColor / 256.0))
            && all(lessThanEqual(color.rgb, levelColor / 254.0)))
        || color.rgb == vec3(0.0);
}

void main() {
    vec3 pos = Position;
    vec2 ui = ceil(2.0 / vec2(ProjMat[0][0], -ProjMat[1][1]));
    vertexColor = Color * texelFetch(Sampler2, UV2 / 16, 0);

    // HUD glyphs carry their position in a huge ascent, which parks them far
    // below the screen. Bring them back and apply the state they were tagged with.
    if (ProjMat[3].x == -1.0 && pos.y >= ui.y) {
        int bits = int(pos.y) >> HEIGHT_BIT;
        if (((bits >> MAX_BIT) & 1) == 1) {
            int id = bits - (1 << MAX_BIT);
            // the boss bar centres its title, so move the origin to the left edge
            pos.x -= 0.5 * ui.x;
            pos.y -= float((bits << HEIGHT_BIT) + ADD_OFFSET + DEFAULT_OFFSET);
            float xGui = 0.0;
            float yGui = 0.0;
            float layer = 0.0;
            switch (id) {
                case 1:
                    xGui = ui.x * 89.0 / 100.0;
                    yGui = ui.y * 2.0 / 100.0;
                    break;
                case 2:
                    xGui = ui.x * 89.0 / 100.0;
                    yGui = ui.y * 2.0 / 100.0;
                    layer = 1.0;
                    break;
                case 3:
                    xGui = ui.x * 89.0 / 100.0;
                    yGui = ui.y * 2.0 / 100.0;
                    layer = 2.0;
                    break;
                case 4:
                    xGui = ui.x * 50.0 / 100.0;
                    yGui = ui.y * 24.0 / 100.0;
                    break;
                case 5:
                    xGui = ui.x * 50.0 / 100.0;
                    yGui = ui.y * 24.0 / 100.0;
                    layer = 2.0;
                    break;
                case 6:
                    xGui = ui.x * 50.0 / 100.0;
                    yGui = ui.y * 24.0 / 100.0;
                    layer = 2.0;
                    break;
                case 7:
                    xGui = ui.x * 50.0 / 100.0;
                    yGui = ui.y * 2.0 / 100.0;
                    break;
                case 8:
                    xGui = ui.x * 50.0 / 100.0;
                    yGui = ui.y * 2.0 / 100.0;
                    layer = 1.0;
                    break;
                case 9:
                    xGui = ui.x * 50.0 / 100.0;
                    yGui = ui.y * 2.0 / 100.0;
                    layer = 2.0;
                    break;
                case 10:
                    xGui = ui.x * 50.0 / 100.0;
                    yGui = ui.y * 88.0 / 100.0;
                    break;
                case 11:
                    xGui = ui.x * 50.0 / 100.0;
                    yGui = ui.y * 88.0 / 100.0;
                    layer = 1.0;
                    break;
                case 12:
                    xGui = ui.x * 50.0 / 100.0;
                    yGui = ui.y * 88.0 / 100.0;
                    layer = 2.0;
                    break;
                case 13:
                    xGui = ui.x * 99.0 / 100.0;
                    yGui = ui.y * 90.0 / 100.0;
                    break;
                case 14:
                    xGui = ui.x * 99.0 / 100.0;
                    yGui = ui.y * 90.0 / 100.0;
                    layer = 2.0;
                    break;
                case 15:
                    xGui = ui.x * 50.0 / 100.0;
                    yGui = ui.y * 12.0 / 100.0;
                    break;
                case 16:
                    xGui = ui.x * 50.0 / 100.0;
                    yGui = ui.y * 12.0 / 100.0;
                    layer = 1.0;
                    break;
                case 17:
                    xGui = ui.x * 50.0 / 100.0;
                    yGui = ui.y * 12.0 / 100.0;
                    layer = 2.0;
                    break;
                case 18:
                    xGui = ui.x * 50.0 / 100.0;
                    yGui = ui.y * 80.0 / 100.0;
                    layer = 2.0;
                    break;
            }
            pos.x += xGui;
            pos.y += yGui;
            pos.z += layer;
        }
    } else if (isVanillaLevelText(pos, ui, Color)) {
        vertexColor = vec4(0.0);
    }

    vertexDistance = fog_distance(pos, FogShape);
    texCoord0 = UV0;
    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);
}
